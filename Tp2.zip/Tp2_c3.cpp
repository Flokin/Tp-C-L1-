#include <iostream>
#include <math.h>
#include <cmath>
/*Excercice 3*/
using namespae std ;

void equation( double x, double y,double di, double z)
{
	if (x==0)
	{
		if (y==0)
		{
			if (z==0)
			{
				cout<<"Une infinité de solutions"<<endl;
			}
		else
		{
		cout<<"Aucune solutions"<<endl;
		}
		}
	else
	{
	cout<<"S={-c/b}"<<endl;
	}
	}
	else
	{
		cout<<"Delta=b²-4*ac "<<endl;
		cout<<"si (Delta > 0) alors 2 solutions "<<endl;
		cout<<"si (Delta < 0) alors 0 solutions "<<endl;
		cout<<"si (Delta = 0) alors une solutiion "<<endl;
	}
}

double delta(double x,double y, double z)
{
	return pow(y,2)-4*x*z;
}

void solution(double x,double y, double z,double di,double& u,double& v)
{

	
	if (di==0)
	{
		u=-y/2*x;

	}
	else if (di>0)
	{
		u=(-y-sqrt(di))/(2*x);
		v=(-y+sqrt(di))/(2*x);

	}
	
	else
	{
		u=(-y-sqrt(-di))/(2*x);
		v=(-y+sqrt(-di))/(2*x);

	}
}

void affiche(double x,double y, double z,double di,double& u,double& v)
{
	if(di==0)
	{
	cout<<u<<endl;
	}
	else
	{
	cout<<u<<endl;
	cout<<v<<endl;
	}
}
int main()
{
	int a;
	int b;
	int c;
	double di;
	double i;
	double j;
	
	cout<<"Rentrez une valeur pour a : "<<endl;
	cin>>a;
	cout<<"Rentrez une valeur pour b : "<<endl;
	cin>>b;
	cout<<"Rentrez une valeur pour c : "<<endl;
	cin>>c;
	
	di=delta(a,b,c);
	equation(a,b,c,di);
	cout<<"\n";
	solution(a,b,c,di,i,j);
	affiche(a,b,c,di,i,j);
	
}



