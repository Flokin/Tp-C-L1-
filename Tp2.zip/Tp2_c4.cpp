#include <iostream>
#include <math.h>
#include <cstdlib>
/*Excercice 4*/
using namespace std ;

void retur(int a, int& b, int& c)
{
	b=a/100;
	c=a-b*100;
}
int main()
{
	int a=0;
	int b=0;
	int c=0;
	int l=0;
	
	cout<<"Entrez un nombre à 4 chiffre"<<endl;
	cin>>a;
	
	l=log10(a)+1;
	
	while(l!=4)
	{
	cout<<"Je vous ai demandé un nombre de 4 chiffre ! "<<endl;
	cout<<"Entrez un nombre à 4 chiffre"<<endl;
	cin>>a;
	}
	retur(a,b,c);
	cout<<b<<endl;
	cout<<c<<endl;
}




