#include <iostream>
#include <math.h>

/*Excercice 2*/
using namespace std ;


int main()
{
	int n(0);
	    cout<<"Entrez un nombre entier :";
		cin>>n;

	int s(0);
	s=log10(n)+1;
	cout<<"Le nombres de chiffre qui compose se nombre est : "<<s;
}



