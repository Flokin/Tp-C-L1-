#include <iostream>


/*Excercice 1*/
using namespace std ;

bool est_premier(int v)
{
    int i;
	for(i=2;i<v;i++)
	{
		if((v%i)==0) 
		{
			return false;
		}
	}
	return true;
}

int main()
{
	while(true)
	{
		int n(0);
	    cout<<"Entrez un nombre supérieur a 0 :";
		cin>>n;
	
		while(n<0)
		{
			cout<<"Je vous ai demandé un nombre supérieur a 0 ! ";
			cout<<"Entrez un nombre supérieur a 0 :";
			cin>>n;
		}
		int i(0);
	    cout<<"Entrez un nombre supérieur a "<<n<<" : ";
		cin>>i;
	
		while(i<n)
		{
			cout<<"Je vous ai demandé un nombre supérieur a "<<n<<" : ";
			cout<<"Entrez un nombre supérieur a "<<n<<" : ";
			cin>>i;
		}
		
		int j(0);
		for (j=n+1;j<=i;j++)
		{
			if(est_premier(j))
			{
				cout<<j<<" est premier"<<endl;
			}
	
		}
	}
}

