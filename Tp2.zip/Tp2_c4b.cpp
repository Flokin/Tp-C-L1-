#include <iostream>
#include <string>
#include <cmath>
/*Excercice 4*/
using namespace std ;

void ret(int an, int& ns, int& as)
{
	ns=an/100 ;
	as=an-ns*100 ;
}


void jour(int j, int m, int an,int& ns, int& as)
{
	int m1, prime ;
	if (m>=3)
	{
		m1=m-2 ; prime=an ;
	}
	if (m<3) 
	{
		m1=m+10 ; prime=an-1 ;
	}
	ret(prime, ns, as) ;
	int f ;
	
	f=(j+as+(as/4)-(2*ns)+(ns/4)+(((26*m1)-2)/10))%7 ;
	
	switch (f)
	{
		case (0) :
			cout<<"Dimanche"<<endl; 
			break ;
		case (1) :
			cout<<"Lundi"<<endl; 
			break ;
		case (2) :
			cout<<"Mardi"<<endl; 
			break ;
		case (3) :
			cout<<"Mercredi"<< endl ; 
			break ;
		case (4) :
			cout<<"Jeudi"<<endl; 
			break ;
		case (5) :
			cout<<"Vendredi"<<endl; 
			break ;
		case (6) :
			cout<<"Samedi"<<endl; 
			break ;
	}
}

int main()
{
	int j, m, an, ns, as, cpt, choix, n ;

	cpt=1;

	do
	{
		cout<<"Entrer un jour = "; 
		cin>>j;
		do
		{
			cout<<"Entrer le mois = ";
			cin>>m;
			if (m > 12)
			{
				 cout<<"Il n'y a que 12 mois dans l'année ! "<<endl;
			}
		} 
		while (m>12) ;
		do
		{
			cout << "L'annee = " ; 
			cin >> an ;
			n=(log10(an)+1) ;
			if (n!=4) 
			{
				cout << "Il nous faut 4 chiffres" << endl ;
			}
		}
		
		 while (n!=4);

		jour(j,m,an, ns, as);

		cout<<"\n"<<"une autre date ? (0/1) : "; 
		cin>>choix;
		cout<<endl;

		if (choix==1)
		{
			cpt=0 ;
		}
	} 
	while (cpt==1) ;
	return 0 ;
}
