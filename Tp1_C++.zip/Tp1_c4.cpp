#include <iostream>
#include <string>
/*Excercice 4*/
using namespace std;

int main()
{
	int l;
	cout<<"Donnez la largeur du carré ? ";
	cin>>l;
	while (l<1)
	{
		cout<<"Désolé "<<l<<" est inférieur a 1 \n"<<"Donnez la largeur du carré ? ";
		cin>>l;
	}
	int i;
	int j;
	for(i=0; i<l; i++)
	{
		for(j=0; j<l; j++)
		{
			cout<<" *";
		}
		cout<<"\n";
	}
	return (0);
}

