#include <iostream>
#include <string>
/*Excercice 1*/
using namespace std ;

int main()
{
	while(true)
	{
		int n;
	    cout<<"Entrez un nombre supérieur a 1 :";
		cin>>n;
	
		while(n<1)
		{
			cout<<"Je vous ai demandé un nombre supérieur a 1 ! ";
			cout<<"Entrez un nombre supérieur a 1 :";
			cin>>n;
		}
		int i;
		for(i=2;i<n;i++)
		{
			if((n%1)==0)break;
		}
	
		if(i==n)
		{
			cout<<n<<" est premier"<<endl;
		}
		else
		{
			cout<<n<<" n'est pas premier "<<endl;
		}
	}
}

