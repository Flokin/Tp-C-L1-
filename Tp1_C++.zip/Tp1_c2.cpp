#include <iostream>
#include <string>
/*Excercice 2*/
using namespace std ;

int main()
{
	while(true)
	{
		int n;
	    cout<<"Donnnez n :";
		cin>>n;
	
		while(n<1)
		{
			cout<<"Desole :"<<n<<"est negatif !";
			cout<<"Donnnez n :";
			cin>>n;
		}	
		int i;
		int j;
		int c;
		for (i=2;i<n;i++)
		{
			c=0;
			for(j=1;j<=i;j++)
			{
				if((i%j)==0)
				{
					c++;
				}
			}
			if(c==2)
			{
				cout<<i<<" est premier \n";
			}
			else
			{
				cout<<i<<" n'est pas premier \n";
			}
		}
	}
}

