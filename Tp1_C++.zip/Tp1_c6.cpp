#include <iostream>
#include <string>
/*Excercice 6*/
using namespace std;

int main()
{
	int t;
	cout<<"Donnez la taille du carré ? ";
	cin>>t;
	while ((t%2)==0)
	{
		cout<<"Désolé, seulement des impaires\n"<<"Donnez la taille du carré ? ";
		cin>>t;
	}

	int i;
	int j;
	for(i=0; i<t; i++)
	{
		for(j=0; j<t; j++)
		{
			if(i==j || j==t-1-i) 
			{
				cout<<" *";
			}		
			else
			{
				cout<<"  ";
			}
		}	
		cout<<"\n";	
	}
	return (0);
}
