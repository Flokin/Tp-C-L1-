#include <iostream>
#include <string>
/*Excercice 3*/
using namespace std ;

int main()
{
	int n;
	cout<<"Donnnez n :";
	cin>>n;
	
	while(n<0)
		{
			cout<<"Desole :"<<n<<"est negatif !";
			cout<<"Donnnez n :";
			cin>>n;
		}	
	
	int cpt=1;
	int val;
	cout<<"Donnez la valeur"<<cpt<<"? :";
	cin>>val;
	int min=val;
	int max=val;
	int t=val;
	float m=(t/cpt);

	if (n>1)
	{	
		while (cpt<n)
		{	
			cout<<"Donnez la valeur "<<cpt<<"? ";
			cin>>val;
			cpt++;
			t=t+val;
			m=(t/cpt);
			if (val<min)
			{
				min=val;
			}
			if (val>max)
			{
				max=val;
			}		
		}
	}
	cout<<"La valeur minimale est : "<<min<<"\nLa valeur maximale est : "<<max<<"\nLa moyenne est : "<<m;
	return(0);
}
