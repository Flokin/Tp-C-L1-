#include <iostream>
#include <string>
/*Excercice 5*/
using namespace std;

int main()
{
	int l;
	cout<<"Donnez la largeur du carré ? ";
	cin>>l;
	while (l < 0)
	{
		cout<<"Désolé, seulement des valeurs positives\n"<<"Donnez la largeur du carré ? ";
		cin>>l;
	}
	int h;
	cout<<"Donnez la hauteur du carré ? ";
	cin>>h;
	while (h < 0)
	{
		cout<<"Désolé, seulement des valeurs positives\n"<<"Donnez la hauteur du carré ? ";
		cin>>h;
	}
	int i;
	int j;
	for(i=0; i<h; i++)
	{
		for(j=0; j<l; j++)
		{
			if(j==0 or i==0 or i==(h-1) or j==(l-1)) 
			{
				cout<<" *";
			}		
			else
			{
				cout<<"  ";
			}
		}	
		cout<<"\n";	
	}
	return (0);
}
