#ifndef DEF_POINT_H_
#define DEF_POINT_H_


class collection_entiers
{
	int *D ;
	int taille ; // Nmax est la taille du tableau
	int n ; //nbe est le nombre d'éléments dans le tableau, au début nbe=0 ;
	
	public :
		collection_entiers(int Nmax) ;
		void affiche();
		~collection_entiers();
		bool ajout(int a);
		bool present(int b);
		void occurence(int occ);
		void moyenne(int &min, int &max, int &moy);
} ;
#endif
