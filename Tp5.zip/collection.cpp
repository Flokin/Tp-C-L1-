#include "collection.h"
#include <iostream>
#include <math.h>

using namespace std;

collection_entiers::collection_entiers(int n)
{
	taille=n;
	D=new int[n];
	
	for (int i(0);i<n;i++) D[i]=0.0;
}

collection_entiers::~collection_entiers()
{
	cout<<"\n Le destructeur est passé .... \n ";
	delete [] D;
}

void collection_entiers::affiche()
{
	cout<<" une collection de 100 places vient d'être crée \n";
	cout<<"[";
	for(int i(0);i<taille;i++)
	{
		cout<<D[i]<<" ";
	}
	cout<<"]";
}

bool collection_entiers::ajout(int a)
{
	if (n<taille) 
	{
		D[n]=a;
		n++;
		return true;
	}
	
	else
	{
		return false;
	}
}

bool collection_entiers::present(int b)
{
	for (int i(0);i<n;i++)
	{
		if (D[i]==b)
		{
			return true;
		}
	}
	
	return false;
}

void collection_entiers::occurence(int occ)
{
	for (int i(0);i<n;i++)
	{
		if(D[i]==occ)
		{
			D[i]=0;
		}
	}
}

void collection_entiers::moyenne(int &min, int &max, int &moy)
{
	int cpt(0);
	for (int i(0);i<n;i++)
	{
		moy+=D[i];
		if(D[i]>max)
		{
			max=i;
		}
		else if (D[i]<min)
		{
			min=i;
		}
	}
	moy/=cpt;
}
