#include "collection.h"
#include "collection.cpp"

using namespace std ;

int main()
{
	/* Ex 1*/
	//collection_entiers C(100) ;
	
	/* Ex 2*/
	//collection_entiers C0(100) ;
	//collection_entiers C1(100) ;
	//		{
	//			collection_entiers C2(100) ;
	//				{
	//					collection_entiers C2(100) ;
	//				}
	//		}
	
	/* Ex 3*/
	
	//collection_entiers C0(100) ;
	//C0.ajout(3) ;
	//C0.ajout(10) ;
	
	/* Ex 4*/
	//collection_entiers C(100) ;
	//C.affiche();
	
	/* Ex 5*/
	//collection_entiers C(100) ;
	//C.ajout(4) ;
	//C.ajout(8) ;
	//if(C.present(3))
	//	{
	//	cout<<"Oui 3 appartient ...." ;
	//	}
	//else
	//	{
	//	cout<<"Non 3 n'appartient pas ...." ;
	//	}
	
	/* Ex 6*/
	/* Ex 7*/
	collection_entiers C(100) ;
	C.moyenne();
}
