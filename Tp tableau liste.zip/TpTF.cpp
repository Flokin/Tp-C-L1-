#include <iostream>

/*Excercice 1*/
using namespace std ;

int main()
{
	const int valeur=10;
	int tableau[valeur];
	for(int i=0; i<5; i++)
	{
		cout<<tableau[i];
	}
}
/*La taille occuper par le tableaux est de 40 octes*/
/* L'instruction "*(&(T[3])) =5, afficher T[3]" est une instruction d'affichage*/
/*
