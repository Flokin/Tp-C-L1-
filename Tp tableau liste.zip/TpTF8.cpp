#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 8*/
using namespace std ;


const int N=10 ;

void affi(int *Tab, int t)
{
  for(int i=0 ; i<t ; i++)
  {
    cout<<Tab[i]<< endl ;
  }
}

int trindice(int *Tab, int t, int x)
{
  int trouve=-1 ;

  for(int i=0 ; i<t ; i++)
  {
    if (Tab[i]==x) 
    {
		trouve=i ;
	}
  }
  return trouve ;
}

void deca(int *Tab, int t, int ind, int y)
{
  for(int i=N-1 ; i>ind ; i--)
  {
    Tab[i]=Tab[i-1] ;
  }
  Tab[ind]=y ;
}

int main()
{
  int Tab[N]={1,2,3,4,5,6,7,8,9,10}, x=0, ind=0, y=0 ;

  cout<<"Entrer une valeur pour x : "; 
  cin>>x;

  ind=trindice(Tab,10,x) ;

  if (ind>0) 
	{
	  cout<<"La valeur se trouve à l'indice : "<<x<<endl;
	}
  else 
	{
	  cout<<endl; 
	}
  cout<<"Entrer une valeur pour y : "; 
  cin>>y;
  
  deca(Tab,10,ind,y) ;
  
  cout<<"Voici votre tableau " <<endl;
  
  affi(Tab,10) ;
  
  return 0 ;
}

