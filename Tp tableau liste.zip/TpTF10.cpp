#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 10*/
using namespace std;

const int x=5, y=10, z=x+y ;

void fusion(int *tab1, int *tab2, int *tabf)
{
  int i=0, j=0, k=0 ;

  while(i<x && j<y)
  {
    if(tab1[i]<tab2[j]) {tabf[k]=tab1[i] ; k++ ; i++ ;}
    else {tabf[k]=tab2[j] ; k++ ; j++ ;}
  }

  while(k<z)
  {
    if(x<y) {tabf[k]=tab2[j] ; k++ ; j++ ;}
    else {tabf[k]=tab1[i] ; k++ ; i++ ;}
  }
}


int main()
{
	int tab1[x]={1,3,5,7,9}, tab2[y]={11,12,14,15,17,18,20,21,30,40}, tabf[z] ;

  fusion(tab1,tab2,tabf) ;

	for (int u=0 ; u<z ; u++)
	{
		cout <<tabf[u]<< endl ;
	}

	return 0 ;
}
