#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 7*/
using namespace std ;

void affiche(int *tab, int ind, int a, int b, int& cpta, int& cpt, int& cptb)
{
	for(int i(0); i<ind; ++i)
	{ 
		if (tab[i]<a)
		{
			cpta=cpta+1;
		}
		else if(tab[i]<b)
		{
			cptb=cptb+1;
		}
		else
		{
			cpt=cpt+1;
		}
	}

}
int main()
{
	int cpta(0);
	int cpt(0);
	int cptb(0);
	int tab[10]={1,2,3,4,5,6,7,8,9,10};
	affiche(tab,10,2,4,cpta,cpt,cptb);
	cout<<"Nombre de valeurs inférieures à a : "<<cpta<<endl;
	cout<<"Nombre de valeurs supérieures à b : "<<cptb<<endl;
	cout<<"Nombre de valeurs entre a et b : "<<cpt<<endl;
	return 0;
	
}
