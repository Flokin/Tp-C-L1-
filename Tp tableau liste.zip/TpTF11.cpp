#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 11*/
using namespace std ;

int const N=10 ;


int nul(int *Tab, int t) 
{
  int cpt=0 ;
  for(int i=0 ; i<t ; i++)
  {
    if(Tab[i]!=0) 
    {
		cpt++ ;
	}
  }
  return cpt ;
}

void del(int *tabf, int *Tab, int t) 
{
  int c=0 ;
  for(int i=0 ; i<t ; i++)
  {
    if(Tab[i]!=0) 
    {
		tabf[i-c]=Tab[i] ;
	}
    else {c++ ;}
  }
}

int main()
{
  int Tab[N]={1,0,2,0,3,0,4,0,0,6}, b=0 ;
  b=nul(Tab,10) ;
  cout<<b<<"est le nombre de valeur différente de 0"<<endl;
  int tabf[b] ;
  del(tabf,Tab,10) ;
  for(int i=0 ; i<b ; i++)
  {
    cout<<tabf[i]<<endl ;
  }
  return 0 ;
}
