#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 2*/
using namespace std ;
int main()
{
int const tab(10);         
int tabl[tab];  
int rand_a_b(int a, int b);
int a(1);
int b(20);
tabl[0]=rand()%(b+a);
tabl[1]=rand()%(b+a);
tabl[2]=rand()%(b+a);
tabl[3]=rand()%(b+a);
tabl[4]=rand()%(b+a);
tabl[6]=rand()%(b+a);
tabl[7]=rand()%(b+a);
tabl[8]=rand()%(b+a);
tabl[9]=rand()%(b+a);
tabl[10]=rand()%(b+a);

for(int i(0); i<tab; ++i)
{ 
    cout << tabl[i] << endl;
}
return 0;
}
