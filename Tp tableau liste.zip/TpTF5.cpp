#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 5*/
using namespace std ;

void affiche(int *tab, int ind)
{
	for(int i(0); i<ind; ++i)
	{ 
		cout<<tab[i]<<endl;
	}
}
int main()
{
	int tab[10]={1,5,45,9,9,6,5,65,8,256};
	affiche(tab,10);
	return 0;
	
}
