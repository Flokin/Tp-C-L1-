#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 6*/
using namespace std ;

void affiche(int *tab, int ind, int n)
{
	bool valeur;
	for(int i(0); i<ind; ++i)
	{ 
		if (tab[i]==n)
		{
			valeur=true;
			break;
		}
	}
	if (valeur==true)
	{
		cout<<"Votre valeur est dans le tableau"<<endl;
	}
	else
	{
		cout<<"Votre valeur n'est pas dans le tableau"<<endl;
	}
}
int main()
{
	int tab[10]={1,5,45,9,9,6,5,65,8,256};
	affiche(tab,10,4);
	return 0;
	
}
