#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 4*/
using namespace std ;
int main()
{
int N(0);
int x(0);
cout<<"entrez la taille du tableau"<<endl;
cin>>N;
int const tab(N);         
int tabl[tab];  
for(int i(0); i<N; ++i)
{ 
	cout<<"entrez une valeurs"<<endl;
	cin>>x;
	tabl[i]=x;
}
	cout<<"Voici votre tableau"<<endl;
for(int i(0); i<tab; ++i)
{ 
    cout << tabl[i] << endl;
}
return 0;
}

