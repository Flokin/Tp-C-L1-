#include <iostream>
#include <cstdlib>
#include <time.h> 

/*Excercice 9*/
using namespace std ;

void inters(int *a, int *b, int *w, int Tab1, int Tab2, int& cpt)
{
  cpt=0 ;
  for(int i=0 ; i<Tab1 ; i++)
  {
    for(int j=0 ; j<Tab2 ; j++)
    {
      if(a[i]==b[j])
      {
        w[cpt]=a[i] ;
        cpt++ ;
      }
    }
  }
}

void afficher(int *c, int& cpt)
{
  cout << "Voici les intersection des tableaux" << endl ;

  for(int i=0 ; i<cpt ; i++)
  {
    cout<<c[i]<< endl ;
  }
}

int main()
{
  int const Tab1=10, Tab2=10, Tabf=2*Tab1 ;
  int a[Tab1]={0,5,10,15,20,25,30,35,40,45}, b[Tab2]={0,10,20,30,40,50,60,70,80}, w[Tabf], cpt ;

  inters(a,b,w,Tab1,Tab2,cpt) ;
  afficher(w,cpt) ;

  return 0 ;
}
